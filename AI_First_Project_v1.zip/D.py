import pandas as pd
import numpy as np
import matplotlib.pyplot as plt


#Load file using Pandas :
dataset = pd.read_excel('optimal_dataset.xlsx')

# رسم تابع چگالي يا احتمال يا توزيع آماري
dataset.plot(kind='density', subplots=True, layout=(3,3), figsize=(20, 15), sharex=False)
plt.show()
