import pandas as pd
import numpy as np
import matplotlib.pyplot as plt


#Load file using Pandas :
dataset = pd.read_excel('optimal_dataset.xlsx')

# رسم هيستوگرام هر يک از ويژگي ها
dataset.hist(bins=50, figsize=(20, 15))
plt.show()
