import pandas as pd
import numpy as np
from pandas.api.types import is_string_dtype

#Load file using Pandas :
pima = pd.read_excel('dataset.xlsx')


#delete rows with null value in it :
pima_op = pima.dropna(how='any',axis=0)

#delete row that has bad format type 
for col in pima_op.columns:
  if is_string_dtype(pima_op[col]):
     pima_op = pima_op[~pima_op[col].str.contains("[a-zA-Z]").fillna(False)]                                                                  

                                                                                            
#removing duplicate rows:
pima_op = pima_op.drop_duplicates(inplace = False)


#delete row that has bad value type
for x in pima_op.index:
  if pima_op.loc[x, "A1"] > 20:
     pima_op = pima_op.drop(x, inplace = False)
     
for x in pima_op.index:
  if pima_op.loc[x, "A2"] == 0 :
     pima_op = pima_op.drop(x, inplace = False)
     
for x in pima_op.index:
  if pima_op.loc[x, "A3"] == 0 :
     pima_op = pima_op.drop(x, inplace = False)

for x in pima_op.index:
  if pima_op.loc[x, "A6"] == 0 :
     pima_op = pima_op.drop(x, inplace = False)
     
for x in pima_op.index:
  if pima_op.loc[x, "A7"] == 0 :
     pima_op = pima_op.drop(x, inplace = False)
     
for x in pima_op.index:
  if pima_op.loc[x, "output"] > 1 :
     pima_op = pima_op.drop(x, inplace = False)   

#finally update dataset :
print("number of sample after clean dataset:")     
print(pima_op.shape[0])
pima_op.to_excel('optimal_dataset.xlsx', encoding='utf-8', index=False)
    
