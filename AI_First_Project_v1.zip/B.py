import pandas as pd
import numpy as np
from pandas.api.types import is_string_dtype

#Load file using Pandas :
dataset = pd.read_excel('optimal_dataset.xlsx')

#details of column A1 till A8 :
print("column A1 till A8 min")
min = dataset.min() 
print(min)

print("--------------------")

print("column A1 till A8 max")
max = dataset.max() 
print(max)

print("--------------------")

print("column A1 till A8 median")
median = dataset.median() 
print(median)

print("--------------------")

print("column A1 till A8 mean")
mean = dataset.mean() 
print(mean)

print("--------------------")

print("column A1 till A8 std (standard deviation)")
std = dataset.std() 
print(std)

print("--------------------")

print("column A1 till A8 variance")
variance = dataset.var() 
print(variance)
